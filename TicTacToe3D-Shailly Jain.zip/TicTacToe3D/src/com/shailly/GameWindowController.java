package com.shailly;

import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.paint.Paint;

public class GameWindowController {

    @FXML
    public Label position0,position1,position2,position3,position4,position5,position6,position7,position8;
    @FXML
    public Label position9, position10,position11,position12,position13,position14,position15,position16,position17;
    @FXML
    public Label position18,position19,position20,position21,position22,position23,position24,position25,position26;

    @FXML
    public Label playerLabel;


    @FXML
    public Button button0,button1,button2,button3,button4,button5,button6,button7,button8;
    @FXML
    public Button button9, button10,button11,button12,button13,button14,button15,button16,button17;
    @FXML
    public Button button18,button19,button20,button21,button22,button23,button24,button25,button26;



    private String[] availableSymbols = new String[3];
    private int numberOfMoves = 0;

    @FXML
    public void initialize(){
        availableSymbols[0] = "X";
        availableSymbols[1] = "O";
        availableSymbols[2] = "#";
        playerLabel.setText("Make Move: Player1");
    }

    @FXML
    public void handleMove(Event e){
        Button button = (Button)e.getSource();  // gets the selected button
        int index = numberOfMoves % 3;
        Paint paint = getPaint(availableSymbols[index]);
        switch(button.getText()){
            case "Position 01" :
                position0.setText(availableSymbols[index]);
                position0.setTextFill(paint);
                break;
            case "Position 02" :
                position1.setText(availableSymbols[index]);
                position1.setTextFill(paint);
                break;
            case "Position 03" :
                position2.setText(availableSymbols[index]);
                position2.setTextFill(paint);
                break;
            case "Position 04" :
                position3.setText(availableSymbols[index]);
                position3.setTextFill(paint);
                break;
            case "Position 05" :
                position4.setText(availableSymbols[index]);
                position4.setTextFill(paint);
                break;
            case "Position 06" :
                position5.setText(availableSymbols[index]);
                position5.setTextFill(paint);
                break;
            case "Position 07" :
                position6.setText(availableSymbols[index]);
                position6.setTextFill(paint);
                break;
            case "Position 08" :
                position7.setText(availableSymbols[index]);
                position7.setTextFill(paint);
                break;
            case "Position 09" :
                position8.setText(availableSymbols[index]);
                position8.setTextFill(paint);
                break;
            case "Position 10" :
                position9.setText(availableSymbols[index]);
                position9.setTextFill(paint);
                break;
            case "Position 11" :
                position10.setText(availableSymbols[index]);
                position10.setTextFill(paint);
                break;
            case "Position 12" :
                position11.setText(availableSymbols[index]);
                position11.setTextFill(paint);
                break;
            case "Position 13" :
                position12.setText(availableSymbols[index]);
                position12.setTextFill(paint);
                break;
            case "Position 14" :
                position13.setText(availableSymbols[index]);
                position13.setTextFill(paint);
                break;
            case "Position 15" :
                position14.setText(availableSymbols[index]);
                position14.setTextFill(paint);
                break;
            case "Position 16" :
                position15.setText(availableSymbols[index]);
                position15.setTextFill(paint);
                break;
            case "Position 17" :
                position16.setText(availableSymbols[index]);
                position16.setTextFill(paint);
                break;
            case "Position 18" :
                position17.setText(availableSymbols[index]);
                position17.setTextFill(paint);
                break;
            case "Position 19" :
                position18.setText(availableSymbols[index]);
                position18.setTextFill(paint);
                break;
            case "Position 20" :
                position19.setText(availableSymbols[index]);
                position19.setTextFill(paint);
                break;
            case "Position 21" :
                position20.setText(availableSymbols[index]);
                position20.setTextFill(paint);
                break;
            case "Position 22" :
                position21.setText(availableSymbols[index]);
                position21.setTextFill(paint);
                break;
            case "Position 23" :
                position22.setText(availableSymbols[index]);
                position22.setTextFill(paint);
                break;
            case "Position 24" :
                position23.setText(availableSymbols[index]);
                position23.setTextFill(paint);
                break;
            case "Position 25" :
                position24.setText(availableSymbols[index]);
                position24.setTextFill(paint);
                break;
            case "Position 26" :
                position25.setText(availableSymbols[index]);
                position25.setTextFill(paint);
                break;
            case "Position 27" :
                position26.setText(availableSymbols[index]);
                position26.setTextFill(paint);
                break;
        }
        numberOfMoves++;
        button.setDisable(true);
        switch(numberOfMoves%3){
            case 0:
                playerLabel.setText("Make Move : Player1");
                break;
            case 1:
                playerLabel.setText("Make Move : Player2");
                break;
            case 2:
                playerLabel.setText("Make Move : Player3");
                break;
        }
        if(numberOfMoves == 27){
            playerLabel.setText("Game Over!!");
        }
        if(numberOfMoves >=7){
            boolean result = getWinner();
            if(result){
                // since game is over so disable all the moves
                playerLabel.setText("Game Over!!");
                button0.setDisable(true);
                button1.setDisable(true);
                button2.setDisable(true);
                button3.setDisable(true);
                button4.setDisable(true);
                button5.setDisable(true);
                button6.setDisable(true);
                button7.setDisable(true);
                button8.setDisable(true);
                button9.setDisable(true);
                button10.setDisable(true);
                button11.setDisable(true);
                button12.setDisable(true);
                button13.setDisable(true);
                button14.setDisable(true);
                button15.setDisable(true);
                button16.setDisable(true);
                button17.setDisable(true);
                button18.setDisable(true);
                button19.setDisable(true);
                button20.setDisable(true);
                button21.setDisable(true);
                button22.setDisable(true);
                button23.setDisable(true);
                button24.setDisable(true);
                button25.setDisable(true);
                button26.setDisable(true);
            }
        }
    }

    private Paint getPaint(String string){
        if(string.equals("X")){
            return Paint.valueOf("crimson");
        }else if(string.equals("O")){
            return Paint.valueOf("green");
        }else{
            return Paint.valueOf("blue");
        }
    }

    private boolean getWinner(){
        boolean isWinner = false;
        if(position0.getText().equals(position1.getText()) && position0.getText().equals(position2.getText())){
            // position0 , position1 and position2 contains the same mark
            showAlert(position0.getText());
            isWinner = true;
        }else if(position3.getText().equals(position4.getText()) && position3.getText().equals(position5.getText())){
            // position3 , position4 and position5 contains the same mark
            showAlert(position3.getText());
            isWinner = true;
        }else if(position6.getText().equals(position7.getText()) && position6.getText().equals(position8.getText())){
            // position6 , position7 and position8 contains the same mark
            showAlert(position6.getText());
            isWinner = true;
        }else if(position9.getText().equals(position10.getText()) && position9.getText().equals(position11.getText())){
            // position9 , position10 and position11 contains the same mark
            showAlert(position9.getText());
            isWinner = true;
        }else if(position12.getText().equals(position13.getText()) && position12.getText().equals(position14.getText())){
            // position12 , position13 and position14 contains the same mark
            showAlert(position12.getText());
            isWinner = true;
        }else if(position15.getText().equals(position16.getText()) && position15.getText().equals(position17.getText())){
            // position15 , position16 and position17 contains the same mark
            showAlert(position15.getText());
            isWinner = true;
        }else if(position18.getText().equals(position19.getText()) && position18.getText().equals(position20.getText())){
            // position18 , position19 and position20 contains the same mark
            showAlert(position18.getText());
            isWinner = true;
        }else if(position21.getText().equals(position22.getText()) && position21.getText().equals(position23.getText())){
            // position21 , position22 and position23 contains the same mark
            showAlert(position21.getText());
            isWinner = true;
        }else if(position24.getText().equals(position25.getText()) && position24.getText().equals(position26.getText())){
            // position24 , position25 and position26 contains the same mark
            showAlert(position24.getText());
            isWinner = true;
        }else if(position0.getText().equals(position3.getText()) && position0.getText().equals(position6.getText())){
            // position0 , position3 and position6 contains the same mark
            showAlert(position0.getText());
            isWinner = true;
        }else if(position1.getText().equals(position4.getText()) && position1.getText().equals(position7.getText())){
            // position1 , position4 and position7 contains the same mark
            showAlert(position1.getText());
            isWinner = true;
        }else if(position2.getText().equals(position5.getText()) && position2.getText().equals(position8.getText())){
            // position2 , position5 and position8 contains the same mark
            showAlert(position2.getText());
            isWinner = true;
        }else if(position9.getText().equals(position12.getText()) && position9.getText().equals(position15.getText())){
            // position9 , position12 and position15 contains the same mark
            showAlert(position9.getText());
            isWinner = true;
        }else if(position10.getText().equals(position13.getText()) && position10.getText().equals(position16.getText())){
            // position10 , position13 and position16 contains the same mark
            showAlert(position10.getText());
            isWinner = true;
        }else if(position11.getText().equals(position14.getText()) && position11.getText().equals(position17.getText())){
            // position11 , position14 and position17 contains the same mark
            showAlert(position11.getText());
            isWinner = true;
        }else if(position18.getText().equals(position21.getText()) && position18.getText().equals(position24.getText())){
            // position18 , position21 and position24 contains the same mark
            showAlert(position18.getText());
            isWinner = true;
        }else if(position19.getText().equals(position22.getText()) && position19.getText().equals(position25.getText())){
            // position19 , position22 and position25 contains the same mark
            showAlert(position19.getText());
            isWinner = true;
        }else if(position20.getText().equals(position23.getText()) && position20.getText().equals(position26.getText())){
            // position20 , position23 and position26 contains the same mark
            showAlert(position19.getText());
            isWinner = true;
        }else if(position0.getText().equals(position9.getText()) && position0.getText().equals(position18.getText())){
            // position0 , position9 and position18 contains the same mark
            showAlert(position0.getText());
            isWinner = true;
        }else if(position3.getText().equals(position12.getText()) && position3.getText().equals(position21.getText())){
            // position3 , position12 and position23 contains the same mark
            showAlert(position3.getText());
            isWinner = true;
        }else if(position6.getText().equals(position15.getText()) && position6.getText().equals(position24.getText())){
            // position6 , position15 and position24 contains the same mark
            showAlert(position6.getText());
            isWinner = true;
        }else if(position1.getText().equals(position10.getText()) && position1.getText().equals(position19.getText())){
            // position1 , position10 and position19 contains the same mark
            showAlert(position1.getText());
            isWinner = true;
        }else if(position4.getText().equals(position13.getText()) && position4.getText().equals(position22.getText())){
            // position4 , position13 and position22 contains the same mark
            showAlert(position4.getText());
            isWinner = true;
        }else if(position7.getText().equals(position16.getText()) && position7.getText().equals(position25.getText())){
            // position7 , position16 and position25 contains the same mark
            showAlert(position7.getText());
            isWinner = true;
        }else if(position2.getText().equals(position11.getText()) && position2.getText().equals(position20.getText())){
            // position2 , position11 and position20 contains the same mark
            showAlert(position2.getText());
            isWinner = true;
        }else if(position5.getText().equals(position14.getText()) && position5.getText().equals(position23.getText())){
            // position5 , position14 and position23 contains the same mark
            showAlert(position5.getText());
            isWinner = true;
        }else if(position8.getText().equals(position17.getText()) && position8.getText().equals(position26.getText())){
            // position8 , position17 and position26 contains the same mark
            showAlert(position8.getText());
            isWinner = true;
        }else if(position6.getText().equals(position15.getText()) && position6.getText().equals(position24.getText())){
            // position6 , position15 and position24 contains the same mark
            showAlert(position6.getText());
            isWinner = true;
        }else if(position0.getText().equals(position4.getText()) && position0.getText().equals(position8.getText())){
            // position0 , position4 and position8 contains the same mark
            showAlert(position0.getText());
            isWinner = true;
        }else if(position2.getText().equals(position4.getText()) && position2.getText().equals(position6.getText())){
            // position2 , position4 and position6 contains the same mark
            showAlert(position2.getText());
            isWinner = true;
        }else if(position9.getText().equals(position13.getText()) && position9.getText().equals(position17.getText())){
            // position9 , position13 and position27 contains the same mark
            showAlert(position9.getText());
            isWinner = true;
        }else if(position11.getText().equals(position13.getText()) && position11.getText().equals(position15.getText())){
            // position11 , position13 and position15 contains the same mark
            showAlert(position11.getText());
            isWinner = true;
        }else if(position18.getText().equals(position22.getText()) && position18.getText().equals(position26.getText())){
            // position18 , position22 and position26 contains the same mark
            showAlert(position18.getText());
            isWinner = true;
        }else if(position20.getText().equals(position22.getText()) && position20.getText().equals(position24.getText())){
            // position20 , position22 and position24 contains the same mark
            showAlert(position20.getText());
            isWinner = true;
        }else if(position0.getText().equals(position13.getText()) && position0.getText().equals(position26.getText())){
            // position0 , position13 and position26 contains the same mark
            showAlert(position0.getText());
            isWinner = true;
        }else if(position6.getText().equals(position13.getText()) && position6.getText().equals(position20.getText())){
            // position6 , position13 and position20 contains the same mark
            showAlert(position6.getText());
            isWinner = true;
        }else if(position8.getText().equals(position13.getText()) && position8.getText().equals(position18.getText())){
            // position8 , position13 and position18 contains the same mark
            showAlert(position8.getText());
            isWinner = true;
        }else if(position2.getText().equals(position13.getText()) && position2.getText().equals(position24.getText())){
            // position2 , position13 and position24 contains the same mark
            showAlert(position2.getText());
            isWinner = true;
        }

        return isWinner;
    }

    private void showAlert(String winnerMark){
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setHeaderText(null);
        alert.setTitle("3D-TicTacToe Winner");
        String text = "Hurrah, ";
        switch(winnerMark){
            case "X" :
                text += "Player1 won!!";
                break;
            case "O" :
                text += "Player2 won!!";
                break;
            case "#" :
                text += "Player3 won!!";
                break;
        }
        alert.setContentText(text);
        alert.showAndWait();
    }
}
