package com.shailly;


import javafx.application.Platform;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.paint.Paint;
import java.io.IOException;


public class Controller {
    @FXML
    public Button playButton,instructionsButton,quitButton;

    @FXML
    public void initialize(){

        try{
            playButton.setGraphic(new ImageView(new Image(getClass().getResourceAsStream("playIcon.png"))));
        }catch(Exception e){
            System.out.println("Could not find the icon playIcon.png");
        }

        try{
            instructionsButton.setGraphic(new ImageView(new Image(getClass().getResourceAsStream("instructions.png"))));
        }catch(Exception e){
            System.out.println("Could not find the icon instructions.png");
        }

        try{
            quitButton.setGraphic(new ImageView(new Image(getClass().getResourceAsStream("quit.png"))));
        }catch(Exception e){
            System.out.println("Could not find the icon quit.png");
        }
    }

    @FXML
    public void handleMouseEnterForButton(Event e){
        Button button = (Button)e.getSource();
        button.setTextFill(Paint.valueOf("crimson"));
        button.setScaleX(1.2);
        button.setScaleY(1.2);
    }

    @FXML
    public void handleMouseExitForButton(Event e){
        Button button = (Button)e.getSource();
        button.setTextFill(Paint.valueOf("blue"));
        button.setScaleX(1.0);
        button.setScaleY(1.0);
    }


    @FXML
    public void handlePlayGameButton(){

        Dialog<ButtonType> dialog = new Dialog<>();
        FXMLLoader loader =  new FXMLLoader();
        loader.setLocation(getClass().getResource("gameWindow.fxml"));
        try{
            dialog.getDialogPane().setContent(loader.load());
        }catch(IOException e){
            System.out.println("Could not load the file gameWindow.fxml");
            return;
        }
        // file loaded successfully
        dialog.setTitle("3D-TicTacToe");
        dialog.setResizable(false);
        dialog.getDialogPane().getButtonTypes().addAll(ButtonType.CLOSE);
        dialog.showAndWait();

    }

    @FXML
    public void handleInstructionButton(){
        Dialog<ButtonType> dialog = new Dialog<>();
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(this.getClass().getResource("instructions.fxml"));
        try{
            dialog.getDialogPane().setContent(loader.load());
        }catch(IOException e){
            System.out.println("Could not load the file instructions.fxml");
            return;
        }
        // file loaded successfully
        dialog.getDialogPane().getButtonTypes().add(ButtonType.OK);
        dialog.setTitle("3D-TicTacToe- Instructions");
        dialog.showAndWait();
    }



    @FXML
    public void handleQuitButton(){
        Platform.exit();
    }
}
