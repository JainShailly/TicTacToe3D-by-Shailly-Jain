package com.shailly;

import javafx.fxml.FXML;
import javafx.scene.control.TextArea;

public class Instructions {

    @FXML
    public TextArea textArea;

    @FXML
    public void initialize(){
        String text = "As we all are aware of the 2D versions of the Tic Tac Toe where "
                    + "two players tries to fill up the 3x3 grid using Xs and Os turn by " +
                    " turn and the player who succeeds in placing three of his/her marks in " +
                    "horizontal, vertical or diagonal rows wins the game.\n" +
                    "This game is the extended version of the 2D-version of the Tic Tac Toe game." +
                    " Here we allow three players who tries to fill a 3x3x3 grid using Xs, Os and #s trurn" +
                    " by turn and the player who succeeds in placing three of his/her marks in any horizontal, " +
                    "vertical or diagonal rows in any of the grid wins the game.\n" +
                    "You can consider 3x3x3 grid to be a cube where you can make a patter of three marks on any of the " +
                    "six faces of the cube in either horizontal, vertical or diagonal rows. But also, here you can make" +
                    " a pattern of three marks along the four body diagonals of the cube.\n" +
                    "You can click the labeled button to place your mark. Computer will show you for your turn.";
        textArea.setText(text);
    }

}
